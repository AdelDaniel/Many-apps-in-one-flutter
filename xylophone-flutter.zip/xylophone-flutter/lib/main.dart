import 'package:just_audio/just_audio.dart';
import 'package:flutter/material.dart';

void main() => runApp(XylophoneApp());

class XylophoneApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              BuildKey(color: Colors.red, number: 1, player: AudioPlayer()),
              BuildKey(color: Colors.orange, number: 2, player: AudioPlayer()),
              BuildKey(color: Colors.yellow, number: 3, player: AudioPlayer()),
              BuildKey(color: Colors.green, number: 4, player: AudioPlayer()),
              BuildKey(color: Colors.teal, number: 5, player: AudioPlayer()),
              BuildKey(color: Colors.blue, number: 6, player: AudioPlayer()),
              BuildKey(color: Colors.purple, number: 7, player: AudioPlayer()),
            ],
          ),
        ),
      ),
    );
  }
}

class BuildKey extends StatelessWidget {
  final Color color;
  final int number;
  final AudioPlayer player;

  const BuildKey(
      {Key? key,
      required this.color,
      required this.number,
      required this.player})
      : super(key: key);

  void playAudio(String tune) async {
    await player.setAsset('note$tune.wav');
    player.play();
  }

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: InkWell(
        onTap: () => playAudio('$number'),
        child: Container(color: color),
      ),
    );
  }
}
